<?php include "AJAX-PHP/header.php"; ?>
<!--Modals-->
<?php include "AJAX-PHP/modals.html"; ?>

<div class="container"> <!--DO NOT CLOSE, CLOSED IN FOOTER-->
	<div class="hero-unit"> 
		<div class="row">
			<div class="span12">
				To Be Done.
			</div>
		</div>
	</div>
	
<?php include "AJAX-PHP/footer.php"; ?>
