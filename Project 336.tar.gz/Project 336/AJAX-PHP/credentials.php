<?php
/**
 * @author Roberto Ronderos Botero
 */
define("DBHOST","localhost");
define("DBUSERNAME","csuser");
define("DBPASSWORD","cs659467");
define("DBNAME","RPNS");

?>