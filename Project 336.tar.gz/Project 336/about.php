<!--	
 Author: David A Zafrani
-->
<?php include "AJAX-PHP/header.php" ?>
<div class="container"> <!--DO NOT CLOSE, CLOSED IN FOOTER-->
	<div style="background-color:#e0233c;text-align:center;height:182px">
    	<img src="img/rutgersBanner.png" alt="Banner Rutgers" style="max-height:150px;position:relative;top:41px" />
    </div>
	<div class="well">
    <div class="row-fluid">
  		<div class="span7" style="margin-bottom:25px"><h1>RPNS</h1>...is the potential creation of 3 CS students at Rutgers University.</div>
	</div>
    <div class="row-fluid">
    	<div class="span6"><h3>Who are they?</h3></div> 
        <div class="span9">Even though their identity may very well remain a secret for eternity, some ponder the idea of potential candidates.</div> 
        <div class="span9">This is the best reseachers could come up with.</div>     	
        <table class="span9" >        	
            <tr>
            	<td><img src="img/roberto.png"></td>
                <td><h2>Roberto</h2> At the time of this writing it is beleived that Roberto was heavily invested in the production of RPNS.</td>
            </tr>
            <tr>
            	<td><img src="img/catalina.png"></td>
                <td><h2>Catalina</h2> She shared an equal investment in RPNS as Roberto, there is rumor these two are quite the love birds.</td>
            </tr>
            <tr>
            	<td width="50%"><img src="img/david.png"></td>
                <td width="50%"><h2>David</h2>Not much is known about David at this time.</td>
            </tr>
       </table>
    </div>
    </div>
    
<?php include "AJAX-PHP/footer.php" ?>